package com.aristidevs.composetesting

class ExampleTestClass {
}